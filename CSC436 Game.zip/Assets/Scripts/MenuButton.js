﻿#pragma strict

function OnMouseDown(){

	Application.LoadLevel("Scene_1");	

}